package validacionacceso;

import java.util.Scanner;

public class ValidacionAcceso {

    public static void main(String[] args) {

        try (Scanner teclado = new Scanner(System.in)) {
            String usuarioCorrecto = "admin";
            String contraseñaCorrecta = "1234";
            
            System.out.print("Ingrese el usuario: ");
            String usuario = teclado.nextLine();
            
            System.out.print("Ingrese la contraseña: ");
            String contraseña = teclado.nextLine();
            
            if (usuario.equals(usuarioCorrecto) &&
                    contraseña.equals(contraseñaCorrecta)) {
                
                System.out.println("Acceso concedido");
                
            } else {
                
                System.out.println("Acceso denegado");
            }
        }
    }
}
