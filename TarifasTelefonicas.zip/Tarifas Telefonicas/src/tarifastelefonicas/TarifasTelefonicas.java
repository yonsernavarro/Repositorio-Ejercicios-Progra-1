package tarifastelefonicas;

import java.util.Scanner;

public class TarifasTelefonicas {

    public static void main(String[] args) {

        try (Scanner teclado = new Scanner(System.in)) {
            System.out.print("Ingrese el día de la semana: ");
            String dia = teclado.nextLine().toLowerCase();
            
            System.out.print("Ingrese la cantidad de minutos hablados: ");
            int minutos = teclado.nextInt();
            
            double tarifa = 0;
            
            switch (dia) {
                case "lunes", "martes", "miercoles", "miércoles", "jueves", "viernes" -> tarifa = 50;
                case "sabado", "sábado" -> tarifa = 30;
                case "domingo" -> tarifa = 20;
                default -> {
                    System.out.println("Error: Día no válido.");
                    return;
                }
            }
            
            double total = tarifa * minutos;
            
            System.out.println("Monto total a pagar: ₡" + total);
        }
    }
}

