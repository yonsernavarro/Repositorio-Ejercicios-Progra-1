package evaluadornotas;

import java.util.Scanner;

public class EvaluadorNotas {

    public static void main(String[] args) {

        try (Scanner teclado = new Scanner(System.in)) {
            System.out.print("Ingrese una nota entre 0 y 100: ");
            int nota = teclado.nextInt();
            
            if (nota < 0 || nota > 100) {
                System.out.println("Nota inválida");
            } else if (nota < 60) {
                System.out.println("Reprobado");
            } else if (nota <= 79) {
                System.out.println("Aprobado");
            } else if (nota <= 89) {
                System.out.println("Muy bien");
            } else {
                System.out.println("Excelente");
            }
        }
    }
}