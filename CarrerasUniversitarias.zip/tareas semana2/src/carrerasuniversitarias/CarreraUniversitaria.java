package carrerasuniversitarias;

import java.util.Scanner;

public class CarreraUniversitaria {

    public static void main(String[] args) {

        try (Scanner teclado = new Scanner(System.in)) {
            System.out.println("=== Carreras Disponibles ===");
            System.out.println("1. Ingeniería");
            System.out.println("2. Psicología");
            System.out.println("3. Administración");
            
            System.out.print("Seleccione una opción: ");
            int opcion = teclado.nextInt();
            
            System.out.print("Ingrese su promedio de secundaria: ");
            double promedio = teclado.nextDouble();
            
            switch (opcion) {
                
                case 1 -> {
                    if (promedio >= 85) {
                        System.out.println("Puede ingresar a Ingeniería.");
                    } else {
                        System.out.println("No cumple con el requisito para esta carrera.");
                    }
                }
                    
                case 2 -> {
                    if (promedio >= 80) {
                        System.out.println("Puede ingresar a Psicología.");
                    } else {
                        System.out.println("No cumple con el requisito para esta carrera.");
                    }
                }
                    
                case 3 -> {
                    if (promedio >= 75) {
                        System.out.println("Puede ingresar a Administración.");
                    } else {
                        System.out.println("No cumple con el requisito para esta carrera.");
                    }
                }
                    
                default -> System.out.println("Opción inválida.");
            }
        }
    }
}
