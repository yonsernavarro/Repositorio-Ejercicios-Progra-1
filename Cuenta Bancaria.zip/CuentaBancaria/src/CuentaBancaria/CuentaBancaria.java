package cuentabancaria;

public class CuentaBancaria {

  public  String numeroCuenta;
  public  String nombreCliente;
  public  double saldo;

    public void depositar(double monto) {
        saldo += monto;
        System.out.println("Depósito realizado con éxito.");
    }

    public void retirar(double monto) {
        if (monto <= saldo) {
            saldo -= monto;
            System.out.println("Retiro realizado con éxito.");
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }

    public void consultarSaldo() {
        System.out.println("Saldo actual: ₡" + saldo);
    }

    
}