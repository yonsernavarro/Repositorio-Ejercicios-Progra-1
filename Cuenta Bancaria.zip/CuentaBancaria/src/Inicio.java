
import cuentabancaria.CuentaBancaria;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author yonse
 */
public class Inicio { public static void main(String[] args) {

    try (Scanner teclado = new Scanner(System.in)) {
        CuentaBancaria cuenta = new CuentaBancaria();

        cuenta.numeroCuenta = "12345";
        cuenta.nombreCliente = "Yonser Navarro";
        cuenta.saldo = 100000;

        int opcion;
        double monto;

        do {
            System.out.println("\n=== SISTEMA BANCARIO ===");
            System.out.println("Cliente: " + cuenta.nombreCliente);
            System.out.println("1. Consultar saldo");
            System.out.println("2. Depositar dinero");
            System.out.println("3. Retirar dinero");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = teclado.nextInt();

            switch (opcion) {

                case 1 -> cuenta.consultarSaldo();

                case 2 -> {
                    System.out.print("Ingrese el monto a depositar: ₡");
                    monto = teclado.nextDouble();
                    cuenta.depositar(monto);
                }

                case 3 -> {
                    System.out.print("Ingrese el monto a retirar: ₡");
                    monto = teclado.nextDouble();
                    cuenta.retirar(monto);
                }

                case 4 -> System.out.println("Gracias por utilizar el sistema bancario.");

                default -> System.out.println("Opción no válida.");
            }

        } while (opcion != 4);
    }
    }
    
}
