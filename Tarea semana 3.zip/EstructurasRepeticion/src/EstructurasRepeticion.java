import java.util.Scanner;

public class EstructurasRepeticion {

    public static void main(String[] args) {

        try (Scanner teclado = new Scanner(System.in)) {
            int opcion;
            
            do {
                System.out.println("\n===== MENU DE EJERCICIOS =====");
                System.out.println("1. Determinar si un número es positivo o negativo");
                System.out.println("2. Juego de adivinanza");
                System.out.println("3. Calcular la media de números positivos");
                System.out.println("4. Mostrar números del 1 al N");
                System.out.println("5. Calcular factorial");
                System.out.println("6. Estadísticas de alumnos");
                System.out.println("7. Registro de ventas del día");
                System.out.println("0. Salir");
                System.out.print("Seleccione una opción: ");
                opcion = teclado.nextInt();
                
                switch (opcion) {
                    
                    case 1:
                        int numero;
                        do {
                            System.out.print("Ingrese un número (0 para salir): ");
                            numero = teclado.nextInt();
                            
                            if (numero > 0) {
                                System.out.println("El número es positivo.");
                            } else if (numero < 0) {
                                System.out.println("El número es negativo.");
                            }
                            
                        } while (numero != 0);
                        break;
                        
                    case 2:
                        System.out.print("Jugador 1, ingrese el número secreto: ");
                        int secreto = teclado.nextInt();
                        
                        int intento;
                        do {
                            System.out.print("Jugador 2, adivine el número: ");
                            intento = teclado.nextInt();
                            
                            if (intento > secreto) {
                                System.out.println("El número ingresado es mayor.");
                            } else if (intento < secreto) {
                                System.out.println("El número ingresado es menor.");
                            }
                            
                        } while (intento != secreto);
                        
                        System.out.println("¡Felicidades! Adivinaste el número.");
                        break;
                        
                    case 3:
                        double num;
                        double suma = 0;
                        int contador = 0;
                        
                        do {
                            System.out.print("Ingrese un número (negativo para terminar): ");
                            num = teclado.nextDouble();
                            
                            if (num >= 0) {
                                suma += num;
                                contador++;
                            }
                            
                        } while (num >= 0);
                        
                        if (contador > 0) {
                            System.out.println("La media es: " + (suma / contador));
                        } else {
                            System.out.println("No se ingresaron números positivos.");
                        }
                        break;
                        
                    case 4:
                        System.out.print("Ingrese un número positivo: ");
                        int n = teclado.nextInt();
                        
                        for (int i = 1; i <= n; i++) {
                            System.out.println(i);
                        }
                        break;
                        
                    case 5:
                        System.out.print("Ingrese un número entero no negativo: ");
                        int factorialNum = teclado.nextInt();
                        
                        long factorial = 1;
                        
                        for (int i = 1; i <= factorialNum; i++) {
                            factorial *= i;
                        }
                        
                        System.out.println("El factorial es: " + factorial);
                        break;
                        
                    case 6:
                        int sumaEdades = 0;
                        double sumaAlturas = 0;
                        int mayores18 = 0;
                        int mayores175 = 0;
                        
                        for (int i = 1; i <= 5; i++) {
                            
                            System.out.println("\nAlumno " + i);
                            
                            System.out.print("Edad: ");
                            int edad = teclado.nextInt();
                            
                            System.out.print("Altura (m): ");
                            double altura = teclado.nextDouble();
                            
                            sumaEdades += edad;
                            sumaAlturas += altura;
                            
                            if (edad > 18) {
                                mayores18++;
                            }
                            
                            if (altura > 1.75) {
                                mayores175++;
                            }
                        }
                        
                        System.out.println("Edad media: " + (double) sumaEdades / 5);
                        System.out.println("Altura media: " + sumaAlturas / 5);
                        System.out.println("Mayores de 18 años: " + mayores18);
                        System.out.println("Miden más de 1.75 m: " + mayores175);
                        break;
                        
                    case 7:
                        double venta;
                        double total = 0;
                        int cantidadVentas = 0;
                        int ventasMayores50000 = 0;
                        
                        do {
                            System.out.print("Ingrese monto de venta (0 para finalizar): ");
                            venta = teclado.nextDouble();
                            
                            if (venta > 0) {
                                total += venta;
                                cantidadVentas++;
                                
                                if (venta > 50000) {
                                    ventasMayores50000++;
                                }
                            }
                            
                        } while (venta != 0);
                        
                        if (cantidadVentas > 0) {
                            System.out.println("Total de ventas: " + cantidadVentas);
                            System.out.println("Monto acumulado: ₡" + total);
                            System.out.println("Promedio: ₡" + (total / cantidadVentas));
                            System.out.println("Ventas mayores a ₡50.000: " + ventasMayores50000);
                        } else {
                            System.out.println("No se registraron ventas.");
                        }
                        break;
                        
                    case 0:
                        System.out.println("Programa finalizado.");
                        break;
                        
                    default:
                        System.out.println("Opción inválida.");
                }
                
            } while (opcion != 0);
        }
    }
}
