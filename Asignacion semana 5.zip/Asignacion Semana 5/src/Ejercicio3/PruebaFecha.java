package ejercicio3;

public class PruebaFecha {

    public static void main(String[] args) {

        Fecha fecha1 = new Fecha(18, 6, 2026);

        System.out.println("Fecha registrada:");
        fecha1.mostrarFecha();
    }
}