package ejercicio1;

public class PruebaFactura {

    public static void main(String[] args) {

        Factura factura = new Factura(
                "A101",
                "Teclado Gamer",
                3,
                15000
        );

        System.out.println("Numero de pieza: " + factura.getNumeroPieza());
        System.out.println("Descripcion: " + factura.getDescripcionPieza());
        System.out.println("Cantidad: " + factura.getCantidad());
        System.out.println("Precio por articulo: ₡" + factura.getPrecioArticulo());
        System.out.println("Monto total: ₡" + factura.obtenerMontoFactura());
    }
}