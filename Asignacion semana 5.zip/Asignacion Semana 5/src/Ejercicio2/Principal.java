package ejercicio2;

public class Principal {

    public static void main(String[] args) {

        Encargado empleado1 = new Encargado(
                "Maria",
                "Lopez",
                800000
        );

        Encargado empleado2 = new Encargado(
                "Carlos",
                "Perez",
                950000
        );

        System.out.println("=== Salario Anual Actual ===");
        System.out.println(empleado1.getNombre() + ": ₡" +
                (empleado1.getSalarioMensual() * 12));

        System.out.println(empleado2.getNombre() + ": ₡" +
                (empleado2.getSalarioMensual() * 12));

        empleado1.setSalarioMensual(
                empleado1.getSalarioMensual() * 1.10);

        empleado2.setSalarioMensual(
                empleado2.getSalarioMensual() * 1.10);

        System.out.println("\n=== Salario Anual con aumento del 10% ===");

        System.out.println(empleado1.getNombre() + ": ₡" +
                (empleado1.getSalarioMensual() * 12));

        System.out.println(empleado2.getNombre() + ": ₡" +
                (empleado2.getSalarioMensual() * 12));
    }
}
